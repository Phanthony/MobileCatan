package com.phanthony.catan.engine

class City(override val player: Int, override val resourceGained: Int = 2): Settlement {
}