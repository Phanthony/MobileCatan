package com.phanthony.catan.engine

class CornerInfo(val cornerID: Int, var settlement: Settlement) {
}