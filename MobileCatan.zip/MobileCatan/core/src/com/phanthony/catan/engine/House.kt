package com.phanthony.catan.engine

class House(override val player: Int, override val resourceGained: Int = 1): Settlement {

}