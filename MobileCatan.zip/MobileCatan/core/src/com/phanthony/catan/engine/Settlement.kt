package com.phanthony.catan.engine

interface Settlement {
    val resourceGained: Int
    val player: Int
}