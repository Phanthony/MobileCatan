package com.phanthony.catan.engine

class Board(val tileList: ArrayList<ArrayList<Tile>>) {

}