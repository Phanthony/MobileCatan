package com.phanthony.catan.database

import androidx.room.Database
